/// This is for the firestore Functions when the file is Created/Updated/Deleted/Written you can do something about it.


const admin = require('firebase-admin');
const functions = require('firebase-functions');

admin.initializeApp(functions.config().firebase);

exports.sendNotification = functions.firestore
    .document('help.current/{Id}').onWrite(
        (change, context) => {
            var payLoad;
            console.log("sendNotification().Change: ", change.after);
            admin.firestore().collection('help.current').doc(context.params.Id).get().then(doc => {
                payLoad = {
                    notification: {
                        title: doc.data().userdetails.name + " requested for help.",
                        badge: '1',
                        sound: 'default'
                    }
                }
                return console.log('sendNotification().help.current worked');
            }).catch(error => {
                console.log('sendNotification().Error: ', error);
            });
            admin.firestore().collection('staffs').get().then(doc => {
                doc.forEach(retToken => {
                    admin.messaging().sendToDevice(retToken.data().token, payLoad);
                })
                return console.log('sendNotification().staffs worked');
            }).catch(error => {
                console.log('sendNotification().Error: ', error);
            });
        }
    );


// exports.statsOnWrite = functions.firestore.document('help.attended/{Id}').onWrite(
//     (change, context) => {
//         console.log("statsOnWrite().Change: ", change, "\nsStatsOnWrite().Context: ", context);
//         var testArray = [];
//         admin.firestore().collection('help.attend').get().then(col => {
//             col.docs.forEach(doc => {
//                 // admin.firestore().collection('stats').doc('stats').set({
//                 //     'test': true,
//                 // });
//                 if (doc.data.details.block !== null) {
//                     testArray.push(doc.data.details.block);
//                 }
//             });
//             console.log("statsOnWrite().testArray: ", testArray);
//             return console.log('statsOnWrite().help.attend worked');
//         }).catch(error => {
//             console.log("statsOnWrite().Error: ", error)
//         })
//     }
// )

// exports.statsOnUpdate = functions.firestore.document('help.attended/{Id}').onUpdate(
//     (change, context) => {
//         console.log("statsOnUpdate().Change: ", change, "\nstatsOnUpdate().Context: ", context);
//         var testArray = [];
//         admin.firestore().collection('help.attend').get().then(col => {
//             col.docs.forEach(doc => {
//                 // admin.firestore().collection('stats').doc('stats').set({
//                 //     'test': true,
//                 // });
//                 if (doc.data.details.block !== null) {
//                     testArray.push(doc.data.details.block);
//                 }
//             });
//             console.log("statsOnUpdate().testArray: ", testArray);
//             return console.log('statsOnUpdate().help.attend worked');
//         }).catch(error => {
//             console.log("statsOnUpdate().Error: ", error)
//         })
//     }
// )